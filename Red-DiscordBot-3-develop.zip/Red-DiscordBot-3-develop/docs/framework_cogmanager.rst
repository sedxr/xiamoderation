.. cog manager docs

===========
Cog Manager
===========

.. automodule:: redbot.core.cog_manager
    :members:
